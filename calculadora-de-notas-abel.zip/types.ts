
export interface CalculationResult {
  grade: number;
  isPassing: boolean;
  percentage: number;
}

export interface SavedCalculation extends CalculationResult {
  id: string;
  date: string;
  totalQuestions: string;
  correctAnswers: string;
}

export interface CalculatorState {
  totalQuestions: string;
  maxGrade: string;
  minPassingGrade: string;
  correctAnswers: string;
}

export interface AIFeedback {
  message: string;
  tips: string[];
}
