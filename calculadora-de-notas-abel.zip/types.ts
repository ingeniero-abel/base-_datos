
export interface CalculationResult {
  grade: number;
  isPassing: boolean;
  percentage: number;
}

export interface CalculatorState {
  totalQuestions: string;
  maxGrade: string;
  minPassingGrade: string;
  correctAnswers: string;
}

export interface AIFeedback {
  message: string;
  tips: string[];
}
