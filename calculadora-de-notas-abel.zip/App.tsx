
import React, { useState, useEffect, useCallback } from 'react';
import { CalculatorState, CalculationResult, AIFeedback, SavedCalculation } from './types';
import { getStudyInsights } from './services/geminiService';

const App: React.FC = () => {
  const [state, setState] = useState<CalculatorState>({
    totalQuestions: '40',
    maxGrade: '7.0',
    minPassingGrade: '4.0',
    correctAnswers: '0',
  });

  const [result, setResult] = useState<CalculationResult | null>(null);
  const [aiFeedback, setAiFeedback] = useState<AIFeedback | null>(null);
  const [history, setHistory] = useState<SavedCalculation[]>([]);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Cargar historial al iniciar
  useEffect(() => {
    const saved = localStorage.getItem('grade_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const calculateGrade = useCallback(() => {
    const total = parseFloat(state.totalQuestions);
    const correct = parseFloat(state.correctAnswers);
    const max = parseFloat(state.maxGrade);
    const minPass = parseFloat(state.minPassingGrade);
    const demand = 0.6; 

    if (isNaN(total) || isNaN(correct) || isNaN(max) || isNaN(minPass) || total <= 0) {
      setResult(null);
      return;
    }

    const passingScore = total * demand;
    const minGrade = 1.0; 
    let grade = 0;

    if (correct >= passingScore) {
      grade = ((max - minPass) * (correct - passingScore) / (total - passingScore)) + minPass;
    } else {
      grade = ((minPass - minGrade) * (correct / passingScore)) + minGrade;
    }

    grade = Math.max(minGrade, Math.min(max, grade));
    const percentage = (correct / total) * 100;

    setResult({
      grade,
      isPassing: grade >= minPass,
      percentage
    });
  }, [state]);

  useEffect(() => {
    calculateGrade();
  }, [calculateGrade]);

  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    setState(prev => ({ ...prev, [field]: value }));
    if (aiFeedback) setAiFeedback(null);
  };

  const saveToHistory = () => {
    if (!result) return;
    const newEntry: SavedCalculation = {
      ...result,
      id: Date.now().toString(),
      date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      totalQuestions: state.totalQuestions,
      correctAnswers: state.correctAnswers
    };
    const updated = [newEntry, ...history].slice(0, 20); // Guardar últimos 20
    setHistory(updated);
    localStorage.setItem('grade_history', JSON.stringify(updated));
    setShowHistory(true);
  };

  const deleteFromHistory = (id: string) => {
    const updated = history.filter(item => item.id !== id);
    setHistory(updated);
    localStorage.setItem('grade_history', JSON.stringify(updated));
  };

  const fetchAIInsights = async () => {
    if (!result) return;
    setIsLoadingAI(true);
    const insights = await getStudyInsights(
      result.grade,
      parseFloat(state.maxGrade),
      result.isPassing,
      result.percentage
    );
    setAiFeedback(insights);
    setIsLoadingAI(false);
  };

  return (
    <div className="flex flex-col items-center px-5 pt-8 pb-12 max-w-md mx-auto min-h-screen relative">
      {/* Header Compacto con botón de Historial */}
      <header className="w-full mb-6 flex justify-between items-center px-2">
        <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
          <span className="bg-indigo-600 px-3 py-1 rounded-xl shadow-lg shadow-indigo-500/20">G</span>
          <span className="text-indigo-400">MASTER</span>
        </h1>
        <button 
          onClick={() => setShowHistory(!showHistory)}
          className="bg-white/5 p-3 rounded-2xl border border-white/10 text-xl hover:bg-white/10 transition-all"
        >
          {showHistory ? '✖' : '📜'}
        </button>
      </header>

      <main className="w-full space-y-6">
        {showHistory ? (
          <section className="glass-card rounded-[2.5rem] p-6 animate-in slide-in-from-right-4 duration-300 min-h-[400px]">
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-indigo-400 mb-6 text-center">Base de Datos Personal</h2>
            <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {history.length === 0 ? (
                <div className="text-center py-20 text-slate-500 italic text-sm">No hay registros guardados.</div>
              ) : (
                history.map(item => (
                  <div key={item.id} className="bg-white/5 border border-white/5 rounded-2xl p-4 flex justify-between items-center group">
                    <div>
                      <div className="text-[10px] text-slate-500 font-bold uppercase mb-1">{item.date}</div>
                      <div className="flex items-center gap-2">
                        <span className={`text-2xl font-black ${item.isPassing ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {item.grade.toFixed(1)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">({item.correctAnswers}/{item.totalQuestions})</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => deleteFromHistory(item.id)}
                      className="p-2 opacity-0 group-hover:opacity-100 text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all"
                    >
                      🗑
                    </button>
                  </div>
                ))
              )}
            </div>
            <button 
              onClick={() => setShowHistory(false)}
              className="w-full mt-6 py-4 border border-indigo-500/30 text-indigo-400 rounded-2xl font-black text-[10px] uppercase tracking-widest"
            >
              Volver al Calculador
            </button>
          </section>
        ) : (
          <>
            {/* Card de Resultado Principal */}
            <section className={`rounded-[2.5rem] p-1 shadow-2xl transition-all duration-500 ${
              result?.isPassing 
              ? 'bg-gradient-to-br from-emerald-400 to-cyan-500' 
              : 'bg-gradient-to-br from-rose-500 to-amber-500'
            }`}>
              <div className="bg-slate-950/80 backdrop-blur-xl rounded-[2.4rem] p-8 flex flex-col items-center text-white relative">
                {result && (
                  <button 
                    onClick={saveToHistory}
                    className="absolute top-6 right-6 bg-white/10 hover:bg-white/20 p-2 rounded-xl text-sm transition-all"
                    title="Guardar en historial"
                  >
                    📥
                  </button>
                )}
                <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">Resultado</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-7xl font-black tracking-tighter">
                    {result ? result.grade.toFixed(1) : '--'}
                  </span>
                  <span className="text-xl font-bold opacity-30">/ {state.maxGrade}</span>
                </div>
                
                <div className={`mt-4 px-5 py-1.5 rounded-full text-xs font-black uppercase tracking-widest border-2 ${
                  result?.isPassing ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400' : 'bg-rose-500/10 border-rose-500/50 text-rose-400'
                }`}>
                  {result?.isPassing ? 'Logrado' : 'Insuficiente'}
                </div>

                <div className="w-full mt-8 bg-white/5 rounded-full h-2 overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ease-out ${
                      result?.isPassing ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.5)]' : 'bg-rose-400 shadow-[0_0_10px_rgba(251,113,133,0.5)]'
                    }`} 
                    style={{ width: `${result?.percentage || 0}%` }}
                  />
                </div>
              </div>
            </section>

            {/* Panel de Entradas */}
            <section className="glass-card rounded-[2rem] p-6 space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <CompactInput 
                  label="PREGUNTAS" 
                  value={state.totalQuestions} 
                  onChange={(v) => handleInputChange('totalQuestions', v)}
                />
                <CompactInput 
                  label="NOTA MÁX" 
                  value={state.maxGrade} 
                  onChange={(v) => handleInputChange('maxGrade', v)}
                />
              </div>
              
              <div className="pt-2">
                <label className="block text-[10px] font-black text-indigo-400 uppercase mb-2 ml-1 tracking-[0.2em]">
                  RESPUESTAS CORRECTAS
                </label>
                <div className="relative">
                  <input
                    type="number"
                    inputMode="numeric"
                    value={state.correctAnswers}
                    onChange={(e) => handleInputChange('correctAnswers', e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-4xl font-black text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-center"
                  />
                </div>
              </div>
            </section>

            {/* AI Insights */}
            <section>
              {!aiFeedback ? (
                <button
                  onClick={fetchAIInsights}
                  disabled={isLoadingAI || !result}
                  className="w-full py-5 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-2xl font-black shadow-lg shadow-indigo-950/40 active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-3"
                >
                  {isLoadingAI ? (
                    <span className="flex items-center gap-2 uppercase text-[10px] tracking-widest">
                      <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      IA Pensando...
                    </span>
                  ) : (
                    <span className="uppercase text-[10px] tracking-[0.2em]">✨ Análisis de Tutor</span>
                  )}
                </button>
              ) : (
                <div className="bg-indigo-600/10 border border-indigo-500/20 rounded-[2rem] p-6 animate-in zoom-in duration-300">
                  <p className="text-indigo-100 text-sm font-medium italic mb-4">"{aiFeedback.message}"</p>
                  <div className="space-y-2">
                    {aiFeedback.tips.slice(0, 2).map((tip, idx) => (
                      <div key={idx} className="flex gap-3 bg-white/5 p-3 rounded-xl">
                        <span className="text-indigo-400 font-black text-xs">#{idx+1}</span>
                        <p className="text-[11px] text-slate-300">{tip}</p>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => setAiFeedback(null)} className="w-full mt-4 text-[9px] font-black text-indigo-400/60 uppercase">Cerrar</button>
                </div>
              )}
            </section>
          </>
        )}
      </main>

      {/* Guía e Info */}
      <footer className="mt-10 text-center space-y-4">
        <button 
          onClick={() => setShowGuide(true)}
          className="text-[9px] font-black text-slate-500 uppercase tracking-widest border border-white/5 px-4 py-2 rounded-full"
        >
          ¿Cómo instalar en mi celular?
        </button>
      </footer>

      {/* Modales */}
      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowGuide(false)}></div>
          <div className="relative glass-card w-full max-w-sm rounded-[2.5rem] p-8">
            <h2 className="text-lg font-black text-white mb-6">GUÍA ANDROID</h2>
            <div className="space-y-4">
              <p className="text-sm text-slate-300">1. Abre en Chrome móvil.</p>
              <p className="text-sm text-slate-300">2. Toca los tres puntos (⋮).</p>
              <p className="text-sm text-slate-300">3. Selecciona 'Instalar aplicación'.</p>
            </div>
            <button onClick={() => setShowGuide(false)} className="w-full mt-8 py-4 bg-indigo-600 rounded-2xl font-black text-xs uppercase text-white">Cerrar</button>
          </div>
        </div>
      )}
    </div>
  );
};

const CompactInput: React.FC<{label: string, value: string, onChange: (v: string)=>void}> = ({ label, value, onChange }) => (
  <div className="space-y-1.5">
    <label className="block text-[9px] font-black text-slate-500 uppercase ml-1 tracking-widest">
      {label}
    </label>
    <input
      type="number"
      inputMode="decimal"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full bg-white/5 border border-white/5 rounded-xl p-3 text-sm font-black text-white focus:outline-none focus:bg-white/10 transition-all"
    />
  </div>
);

export default App;
