
import React, { useState, useEffect, useCallback } from 'react';
import { CalculatorState, CalculationResult, AIFeedback } from './types';
import { getStudyInsights } from './services/geminiService';

const App: React.FC = () => {
  const [state, setState] = useState<CalculatorState>({
    totalQuestions: '40',
    maxGrade: '7.0',
    minPassingGrade: '4.0',
    correctAnswers: '0',
  });

  const [result, setResult] = useState<CalculationResult | null>(null);
  const [aiFeedback, setAiFeedback] = useState<AIFeedback | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState(false);

  const calculateGrade = useCallback(() => {
    const total = parseFloat(state.totalQuestions);
    const correct = parseFloat(state.correctAnswers);
    const max = parseFloat(state.maxGrade);
    const minPass = parseFloat(state.minPassingGrade);
    const demand = 0.6; 

    if (isNaN(total) || isNaN(correct) || isNaN(max) || isNaN(minPass) || total <= 0) {
      setResult(null);
      return;
    }

    const passingScore = total * demand;
    const minGrade = 1.0; 
    let grade = 0;

    if (correct >= passingScore) {
      grade = ((max - minPass) * (correct - passingScore) / (total - passingScore)) + minPass;
    } else {
      grade = ((minPass - minGrade) * (correct / passingScore)) + minGrade;
    }

    grade = Math.max(minGrade, Math.min(max, grade));
    const percentage = (correct / total) * 100;

    setResult({
      grade,
      isPassing: grade >= minPass,
      percentage
    });
  }, [state]);

  useEffect(() => {
    calculateGrade();
  }, [calculateGrade]);

  const handleInputChange = (field: keyof CalculatorState, value: string) => {
    setState(prev => ({ ...prev, [field]: value }));
    if (aiFeedback) setAiFeedback(null);
  };

  const fetchAIInsights = async () => {
    if (!result) return;
    setIsLoadingAI(true);
    const insights = await getStudyInsights(
      result.grade,
      parseFloat(state.maxGrade),
      result.isPassing,
      result.percentage
    );
    setAiFeedback(insights);
    setIsLoadingAI(false);
  };

  return (
    <div className="flex flex-col items-center px-5 pt-10 pb-12 max-w-md mx-auto min-h-screen">
      {/* Header Compacto */}
      <header className="w-full mb-8 text-center">
        <h1 className="text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
          <span className="bg-indigo-600 px-3 py-1 rounded-2xl transform -rotate-2">GRADE</span>
          <span className="text-indigo-400">MASTER</span>
        </h1>
      </header>

      <main className="w-full space-y-6">
        {/* Card de Resultado Principal - Más compacta y visual */}
        <section className={`rounded-[2.5rem] p-1 shadow-2xl transition-all duration-500 ${
          result?.isPassing 
          ? 'bg-gradient-to-br from-emerald-400 to-cyan-500' 
          : 'bg-gradient-to-br from-rose-500 to-amber-500'
        }`}>
          <div className="bg-slate-950/80 backdrop-blur-xl rounded-[2.4rem] p-8 flex flex-col items-center text-white">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60 mb-1">Calificación</span>
            <div className="flex items-baseline gap-1">
              <span className="text-7xl font-black tracking-tighter">
                {result ? result.grade.toFixed(1) : '--'}
              </span>
              <span className="text-xl font-bold opacity-30">/ {state.maxGrade}</span>
            </div>
            
            <div className={`mt-4 px-5 py-1.5 rounded-full text-xs font-black uppercase tracking-widest border-2 ${
              result?.isPassing ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400' : 'bg-rose-500/10 border-rose-500/50 text-rose-400'
            }`}>
              {result?.isPassing ? '¡Aprobado!' : 'Reprobado'}
            </div>

            <div className="w-full mt-8 bg-white/5 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ease-out ${
                  result?.isPassing ? 'bg-emerald-400' : 'bg-rose-400'
                }`} 
                style={{ width: `${result?.percentage || 0}%` }}
              />
            </div>
          </div>
        </section>

        {/* Panel de Entradas Unificado */}
        <section className="glass-card rounded-[2rem] p-6 space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <CompactInput 
              label="TOTAL PREGUNTAS" 
              value={state.totalQuestions} 
              onChange={(v) => handleInputChange('totalQuestions', v)}
            />
            <CompactInput 
              label="NOTA MÁXIMA" 
              value={state.maxGrade} 
              onChange={(v) => handleInputChange('maxGrade', v)}
            />
          </div>
          <CompactInput 
            label="NOTA DE CORTE" 
            value={state.minPassingGrade} 
            onChange={(v) => handleInputChange('minPassingGrade', v)}
          />
          
          <div className="pt-2">
            <label className="block text-[10px] font-black text-indigo-400 uppercase mb-2 ml-1 tracking-[0.2em]">
              PREGUNTAS POSITIVAS
            </label>
            <div className="relative">
              <input
                type="number"
                inputMode="numeric"
                value={state.correctAnswers}
                onChange={(e) => handleInputChange('correctAnswers', e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-4xl font-black text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-center"
              />
              <div className="absolute inset-y-0 right-6 flex items-center pointer-events-none">
                <span className="text-slate-600 font-black text-lg italic">✔</span>
              </div>
            </div>
          </div>
        </section>

        {/* AI Insights - Diseño integrado */}
        <section>
          {!aiFeedback ? (
            <button
              onClick={fetchAIInsights}
              disabled={isLoadingAI || !result}
              className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black shadow-lg shadow-indigo-900/20 active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-3"
            >
              {isLoadingAI ? (
                <span className="flex items-center gap-2 uppercase text-xs tracking-widest">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Analizando...
                </span>
              ) : (
                <span className="uppercase text-xs tracking-[0.2em]">✨ Análisis del Tutor</span>
              )}
            </button>
          ) : (
            <div className="bg-indigo-600/20 border border-indigo-500/30 rounded-[2rem] p-6 animate-in slide-in-from-bottom-2 duration-300">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xl">🤖</span>
                <h3 className="font-black text-xs uppercase tracking-widest text-indigo-300">Feedback IA</h3>
              </div>
              <p className="text-indigo-100 text-sm font-medium italic mb-4">"{aiFeedback.message}"</p>
              <div className="space-y-2">
                {aiFeedback.tips.slice(0, 2).map((tip, idx) => (
                  <div key={idx} className="flex gap-3 items-start bg-white/5 p-3 rounded-xl">
                    <span className="text-indigo-400 font-black text-xs">0{idx+1}</span>
                    <p className="text-xs text-slate-300 leading-tight">{tip}</p>
                  </div>
                ))}
              </div>
              <button 
                onClick={() => setAiFeedback(null)}
                className="w-full mt-4 text-[9px] font-black text-indigo-400/60 uppercase tracking-widest"
              >
                Cerrar
              </button>
            </div>
          )}
        </section>
      </main>

      <footer className="mt-10 text-center space-y-2 opacity-30">
        <p className="text-[10px] font-black text-white uppercase tracking-[0.3em]">GradeMaster v2.0</p>
        <p className="text-[8px] text-slate-400">Optimizado para Pantallas AMOLED</p>
      </footer>
    </div>
  );
};

const CompactInput: React.FC<{label: string, value: string, onChange: (v: string)=>void}> = ({ label, value, onChange }) => (
  <div className="space-y-1.5">
    <label className="block text-[9px] font-black text-slate-500 uppercase ml-1 tracking-widest">
      {label}
    </label>
    <input
      type="number"
      inputMode="decimal"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full bg-white/5 border border-white/5 rounded-xl p-3 text-sm font-black text-white focus:outline-none focus:bg-white/10 transition-all"
    />
  </div>
);

export default App;
