
import { GoogleGenAI, Type } from "@google/genai";
import { AIFeedback } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getStudyInsights = async (
  grade: number,
  maxGrade: number,
  isPassing: boolean,
  percentage: number
): Promise<AIFeedback> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Proporciona un feedback motivador y 3 consejos de estudio breves para un estudiante que obtuvo una nota de ${grade.toFixed(1)} de un máximo de ${maxGrade.toFixed(1)} (${percentage.toFixed(1)}% de logro). El estado de aprobación es: ${isPassing ? 'Aprobado' : 'Reprobado'}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING, description: "Un mensaje breve y motivador." },
            tips: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "3 consejos prácticos de estudio."
            }
          },
          required: ["message", "tips"]
        }
      }
    });

    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr) as AIFeedback;
  } catch (error) {
    console.error("Error fetching AI insights:", error);
    return {
      message: "¡Sigue esforzándote! Cada examen es una oportunidad de aprendizaje.",
      tips: ["Revisa tus errores", "Organiza tu tiempo", "Consulta tus dudas con el profesor"]
    };
  }
};
